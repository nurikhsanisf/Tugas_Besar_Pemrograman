-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 19, 2020 at 11:17 AM
-- Server version: 5.7.28-0ubuntu0.18.04.4
-- PHP Version: 7.2.24-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ehospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `kamar`
--

CREATE TABLE `kamar` (
  `id` int(10) UNSIGNED NOT NULL,
  `no_kamar` int(11) NOT NULL,
  `nama_kamar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_kamar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ukuran_kamar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fasilitas_kamar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kamar`
--

INSERT INTO `kamar` (`id`, `no_kamar`, `nama_kamar`, `jenis_kamar`, `ukuran_kamar`, `fasilitas_kamar`, `created_at`, `updated_at`) VALUES
(1, 1, 'a', 'a', 'a', 'a', '2020-01-17 08:12:33', '2020-01-17 08:12:33');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2020_01_08_105409_create_kamar_table', 1),
(4, '2020_01_17_131228_create_dokter_table', 2),
(5, '2020_01_17_131435_create_jadwal_dokter_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dokter`
--

CREATE TABLE `tbl_dokter` (
  `id_dokter` bigint(20) UNSIGNED NOT NULL,
  `nama_dokter` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `spesifikasi_dokter` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_dokter`
--

INSERT INTO `tbl_dokter` (`id_dokter`, `nama_dokter`, `spesifikasi_dokter`, `created_at`, `updated_at`) VALUES
(8, 'dr.H.Noerony Hidayat', 'Dokter Umum', '2020-01-18 21:03:15', '2020-01-18 21:03:15'),
(9, 'Dr. dr. Aidah Juliaty A. Baso, Sp.A (K)', 'Spesialis Penyakit Dalam', '2020-01-18 21:05:44', '2020-01-18 21:05:44'),
(10, 'dr. A. Dwi Bahagia Febriani, Ph.D., Sp.A (K)', 'Spesialis Penyakit Dalam', '2020-01-18 21:06:09', '2020-01-18 21:06:09'),
(11, 'dr. Amrillah Hamdi', 'bedah', '2020-01-18 21:06:29', '2020-01-18 21:06:29'),
(12, 'dr.H.Yuyu Suparman., Sp.B', 'spesialis bedah', '2020-01-18 21:08:01', '2020-01-18 21:08:01'),
(13, 'dr.H.Enceng., Sp.B', 'Spesialis Bedah', '2020-01-18 21:08:50', '2020-01-18 21:08:50'),
(14, 'dr. H. Soesanto SH. S., Sp.A., MH. Kes', 'Spesialis Kesehatan Anak', '2020-01-18 21:09:53', '2020-01-18 21:09:53'),
(15, 'dr. Endah W.R., Sp.A.M.Kes', 'Spesialis Kesehatan Anak', '2020-01-18 21:10:31', '2020-01-18 21:10:31');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jadwal_dokter`
--

CREATE TABLE `tbl_jadwal_dokter` (
  `id_jadwal_dokter` bigint(20) UNSIGNED NOT NULL,
  `dari_hari` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sampai_hari` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dari_jam` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sampai_jam` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_dokter` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_jadwal_dokter`
--

INSERT INTO `tbl_jadwal_dokter` (`id_jadwal_dokter`, `dari_hari`, `sampai_hari`, `dari_jam`, `sampai_jam`, `id_dokter`, `created_at`, `updated_at`) VALUES
(8, 'Senin', 'Jum\'at', '15.00', '17.00', 8, '2020-01-18 21:12:39', '2020-01-18 21:12:39'),
(9, 'Senin', 'Kamis', '15.00', '17.00', 9, '2020-01-18 21:13:25', '2020-01-18 21:13:25'),
(10, 'Senin', 'Kamis', '07.00', '09:00', 10, '2020-01-18 21:13:57', '2020-01-18 21:13:57'),
(11, 'Selasa', 'Kamis', '16.00', 'selesai', 11, '2020-01-18 21:14:27', '2020-01-18 21:14:27'),
(12, 'Senin', 'Jum\'at', '15.30', 'Selesai', 12, '2020-01-18 21:14:54', '2020-01-18 21:14:54'),
(13, 'Selasa', 'Kamis', '16.00', 'Selesai', 13, '2020-01-18 21:15:21', '2020-01-18 21:15:21'),
(14, 'Selasa', 'Kamis', '15.30', 'Selesai', 14, '2020-01-18 21:15:46', '2020-01-18 21:15:46'),
(15, 'Senin', 'Sabtu', '09:00', '13.00', 15, '2020-01-18 21:16:14', '2020-01-18 21:16:14');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kamar`
--
ALTER TABLE `kamar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `tbl_dokter`
--
ALTER TABLE `tbl_dokter`
  ADD PRIMARY KEY (`id_dokter`);

--
-- Indexes for table `tbl_jadwal_dokter`
--
ALTER TABLE `tbl_jadwal_dokter`
  ADD PRIMARY KEY (`id_jadwal_dokter`),
  ADD KEY `tbl_jadwal_dokter_id_dokter_foreign` (`id_dokter`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kamar`
--
ALTER TABLE `kamar`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_dokter`
--
ALTER TABLE `tbl_dokter`
  MODIFY `id_dokter` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tbl_jadwal_dokter`
--
ALTER TABLE `tbl_jadwal_dokter`
  MODIFY `id_jadwal_dokter` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_jadwal_dokter`
--
ALTER TABLE `tbl_jadwal_dokter`
  ADD CONSTRAINT `tbl_jadwal_dokter_id_dokter_foreign` FOREIGN KEY (`id_dokter`) REFERENCES `tbl_dokter` (`id_dokter`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
